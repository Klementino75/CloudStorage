package ru.netology.cloudstorage.exception;

import com.github.dockerjava.api.exception.NotFoundException;

import lombok.Getter;

@Getter
public class FileNotFoundException extends NotFoundException {
    private final long id;

    public FileNotFoundException(String msg, long id) {
        super(msg);
        this.id = id;
    }
}