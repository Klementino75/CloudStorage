package ru.netology.cloudstorage.exception;

import lombok.Getter;

@Getter
public class InvalidInputData extends RuntimeException {
    private final long id;

    public InvalidInputData(String msg, long id) {
        super(msg);
        this.id = id;
    }
}