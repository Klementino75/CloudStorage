package ru.netology.cloudstorage.exception;

import com.github.dockerjava.api.exception.NotFoundException;

import lombok.Getter;

@Getter
public class UserNotFoundException extends NotFoundException {
    private final long id;

    public UserNotFoundException(String msg, long id) {
        super(msg);
        this.id = id;
    }
}