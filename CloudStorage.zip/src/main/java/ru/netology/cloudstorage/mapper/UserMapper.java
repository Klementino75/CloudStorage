package ru.netology.cloudstorage.mapper;

import org.mapstruct.Mapper;

import ru.netology.cloudstorage.dto.UserDto;
import ru.netology.cloudstorage.entities.User;

@Mapper(componentModel = "spring")
public interface UserMapper {

    User userDtoToUser(UserDto userDto);
    UserDto userToUserDto(User user);
}