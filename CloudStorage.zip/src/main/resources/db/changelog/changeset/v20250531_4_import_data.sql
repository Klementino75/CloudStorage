insert into users (login, password) values ('admin@test.com', '$2a$12$pBqGg4hhFmlYJuRCNadI3ehWlX6EnLdpHgQRnkIinsh6rIPm6ZbyC');
insert into user_roles (roles, user_id) values ('1', 1);

insert into users (login, password) values ('user@test.com', '$2a$12$50fw4HdLHI1Yt1bvPl6eSOK26ndkESQdB6crjzxfX0t/a5IFneeXO');
insert into user_roles (roles, user_id) values ('0', 2);
